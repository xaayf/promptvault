import React, { useState, useEffect, useRef, useMemo, Component } from 'react';
import {
  FolderPlus, Folder, Plus, Search, Copy, Check, Sparkles, Trash2, Edit3,
  Sun, Moon, Download, RefreshCw, ChevronLeft, Tag, FileText,
  AlertTriangle, Zap, Terminal, Code, Cpu, BookOpen, Layers, Database,
  Box, Key, Sparkle, Layout, Heart, FileCode, HardDrive,
  Settings, Activity, Upload, CheckCircle
} from 'lucide-react';
import Logo from './Logo.jsx';

const UI_STYLES = {
  glassPanelLight: "bg-white/80 backdrop-blur-xl border border-white/40 shadow-xl shadow-slate-200/50",
  glassPanelDark: "bg-slate-900/80 backdrop-blur-xl border border-slate-800/80 shadow-2xl shadow-black/50",
  glassInputLight: "bg-slate-100/90 border border-slate-200/80 focus:border-indigo-500/80 focus:bg-white text-slate-800 placeholder-slate-400",
  glassInputDark: "bg-slate-800/70 border border-slate-700/60 focus:border-indigo-400/80 focus:bg-slate-800 text-slate-100 placeholder-slate-500",
  btnPrimary: "bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 hover:from-indigo-600 hover:to-pink-600 text-white font-medium shadow-md hover:shadow-indigo-500/25 transition-all duration-200 active:scale-[0.98]",
  btnSecondaryLight: "bg-slate-200/70 hover:bg-slate-200 text-slate-700 hover:text-slate-900 border border-slate-300/50",
  btnSecondaryDark: "bg-slate-800/70 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700/50"
};

const ICON_MAP = { Terminal, Code, Cpu, BookOpen, Layers, Database, Box, Key, Sparkle, Layout, Heart, FileCode, Folder };
const AVAILABLE_ICONS = ['Folder', 'Code', 'Database', 'BookOpen', 'Cpu', 'Layout', 'Terminal', 'Layers', 'Box', 'Key', 'FileCode'];

// Smart auto-detection of dynamic monoline icons & folder names
const autoDetectFolderMeta = (text, currentLength) => {
  const query = (text || '').toLowerCase().trim();
  if (!query) return { name: `Koleksi Vault #${currentLength + 1}`, icon: 'Folder' };
  if (query.includes('code') || query.includes('react') || query.includes('dev') || query.includes('script') || query.includes('js') || query.includes('python')) return { name: text, icon: 'Code' };
  if (query.includes('sql') || query.includes('data') || query.includes('db') || query.includes('base')) return { name: text, icon: 'Database' };
  if (query.includes('write') || query.includes('copy') || query.includes('book') || query.includes('article') || query.includes('draft')) return { name: text, icon: 'BookOpen' };
  if (query.includes('ai') || query.includes('prompt') || query.includes('llm') || query.includes('gpt') || query.includes('bot')) return { name: text, icon: 'Cpu' };
  if (query.includes('design') || query.includes('ui') || query.includes('ux') || query.includes('layout') || query.includes('figma')) return { name: text, icon: 'Layout' };
  if (query.includes('terminal') || query.includes('cli') || query.includes('bash') || query.includes('shell')) return { name: text, icon: 'Terminal' };
  if (query.includes('api') || query.includes('auth') || query.includes('key') || query.includes('token')) return { name: text, icon: 'Key' };
  return { name: text, icon: 'Folder' };
};

const INITIAL_DATA = [
  { id: 'f-1', name: 'AI Development & Coding', icon: 'Code', createdAt: Date.now() - 1000000, prompts: [{ id: 'p-1', title: 'React Expert Code Reviewer', content: 'Act as a Principal Frontend Engineer. Review the provided React codebase for performance bottlenecks, re-render triggers, accessibility issues, and type safety. Offer concrete refactored snippets.', tags: ['React', 'Code Review', 'Frontend'], variableFields: ['Framework', 'Performance Metric'], isFavorite: true, updatedAt: Date.now() - 500000 }, { id: 'p-2', title: 'SQL Query Optimizer', content: 'Act as a Senior Database Administrator. Analyze the following SQL query for indexing strategies, CTE optimization, and join execution plans.', tags: ['SQL', 'Database'], variableFields: ['Query Target'], isFavorite: false, updatedAt: Date.now() - 400000 }] },
  { id: 'f-2', name: 'Creative Writing & Copywriting', icon: 'BookOpen', createdAt: Date.now() - 800000, prompts: [{ id: 'p-3', title: 'Apple-Style Product Copy', content: 'Craft a product pitch using Apple\'s minimalist, poetic, yet impactful writing style. Emphasize human emotion, breakthrough innovation, and simple elegance.', tags: ['Marketing', 'Copywriting'], variableFields: ['Product Name', 'Key Feature'], isFavorite: true, updatedAt: Date.now() - 300000 }] }
];

const GEMINI_MODEL = 'gemini-3-flash-preview';

const loadFolders = () => {
  try {
    const raw = localStorage.getItem('pv_folders');
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch (e) {}
  return INITIAL_DATA;
};
const loadTheme = () => {
  try {
    const t = localStorage.getItem('pv_theme');
    if (t) return t === 'dark';
  } catch (e) {}
  return true;
};
const loadKey = () => {
  try { return localStorage.getItem('pv_gemini_key') || ''; } catch (e) { return ''; }
};

function PromptVaultApp() {
  const [isDarkMode, setIsDarkMode] = useState(loadTheme);
  const [folders, setFolders] = useState(loadFolders);
  const [selectedFolderId, setSelectedFolderId] = useState(() => folders[0]?.id ?? null);
  const [selectedPromptId, setSelectedPromptId] = useState(null);
  const [mobileView, setMobileView] = useState('folders'); // 'folders' | 'prompts' | 'detail'
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTag, setSelectedTag] = useState(null);
  const [copiedId, setCopiedId] = useState(null);

  const [saveStatus, setSaveStatus] = useState('saved'); // 'saved' | 'error'
  const [storageLogs, setStorageLogs] = useState([]);

  const [isFolderModalOpen, setIsFolderModalOpen] = useState(false);
  const [newFolderName, setNewFolderName] = useState('');
  const [selectedFolderIcon, setSelectedFolderIcon] = useState('Folder');
  const [editingFolderId, setEditingFolderId] = useState(null);

  const [isPromptModalOpen, setIsPromptModalOpen] = useState(false);
  const [editingPrompt, setEditingPrompt] = useState({ id: null, title: '', content: '', tags: '', folderId: '' });

  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isAiGenerating, setIsAiGenerating] = useState(false);
  const [aiPromptInput, setAiPromptInput] = useState('');
  const [showAiModal, setShowAiModal] = useState(false);
  const [geminiKey, setGeminiKey] = useState(loadKey);

  const fileInputRef = useRef(null);

  const addLog = (msg, type = 'info') => {
    const time = new Date().toLocaleTimeString();
    setStorageLogs(prev => [{ time, msg, type }, ...prev].slice(0, 20));
  };

  const mutateFolders = setFolders;

  // Simpan otomatis ke localStorage setiap data berubah (langsung, tanpa debounce
  // supaya aman kalau app tiba-tiba ditutup/pindah ke background di iPhone)
  useEffect(() => {
    try {
      localStorage.setItem('pv_folders', JSON.stringify(folders));
      setSaveStatus('saved');
    } catch (e) {
      setSaveStatus('error');
      addLog('Gagal menyimpan ke penyimpanan perangkat.', 'error');
    }
  }, [folders]);

  // Tema: simpan + sinkronkan warna latar html
  useEffect(() => {
    try { localStorage.setItem('pv_theme', isDarkMode ? 'dark' : 'light'); } catch (e) {}
    document.documentElement.style.backgroundColor = isDarkMode ? '#020617' : '#f8fafc';
  }, [isDarkMode]);

  useEffect(() => {
    try { localStorage.setItem('pv_gemini_key', geminiKey); } catch (e) {}
  }, [geminiKey]);

  // Minta penyimpanan persisten supaya data tidak dibersihkan sistem
  useEffect(() => {
    const standalone = window.matchMedia?.('(display-mode: standalone)').matches || window.navigator.standalone;
    addLog(standalone ? 'Berjalan sebagai aplikasi (Home Screen).' : 'Berjalan di browser. Tambahkan ke Home Screen untuk mode app.', 'info');
    navigator.storage?.persist?.().then(ok => addLog(ok ? 'Penyimpanan persisten aktif.' : 'Penyimpanan standar (belum persisten).', ok ? 'success' : 'info')).catch(() => {});
  }, []);

  const activeFolder = useMemo(() => folders.find(f => f.id === selectedFolderId) || folders[0], [folders, selectedFolderId]);
  
  const allTags = useMemo(() => {
    const set = new Set();
    folders.forEach(f => (f.prompts || []).forEach(p => (p.tags || []).forEach(t => set.add(t))));
    return Array.from(set);
  }, [folders]);

  const filteredPrompts = useMemo(() => {
    if (!activeFolder) return [];
    return (activeFolder.prompts || []).filter(p => {
      const matchesSearch = p.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                            p.content.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesTag = !selectedTag || (p.tags && p.tags.includes(selectedTag));
      return matchesSearch && matchesTag;
    });
  }, [activeFolder, searchQuery, selectedTag]);

  const activePrompt = useMemo(() => {
    if (!activeFolder) return null;
    return activeFolder.prompts.find(p => p.id === selectedPromptId) || filteredPrompts[0] || null;
  }, [activeFolder, selectedPromptId, filteredPrompts]);

  const handleSelectFolder = (folderId) => {
    setSelectedFolderId(folderId);
    setSelectedPromptId(null);
    setMobileView('prompts');
  };

  const handleSelectPrompt = (promptId) => {
    setSelectedPromptId(promptId);
    setMobileView('detail');
  };

  // Smart Auto-Naming & Dynamic Monoline Icon Handler
  const handleSaveFolder = (e) => {
    e.preventDefault();
    if (editingFolderId) {
      // Edit existing folder
      mutateFolders(prev => prev.map(f => {
        if (f.id === editingFolderId) {
          const finalName = newFolderName.trim() || f.name;
          return { ...f, name: finalName, icon: selectedFolderIcon };
        }
        return f;
      }));
      addLog('Folder berhasil diperbarui.', 'info');
    } else {
      // Create new folder
      const meta = autoDetectFolderMeta(newFolderName.trim(), folders.length);
      const newFolder = {
        id: `f-${Date.now()}`,
        name: meta.name,
        icon: newFolderName.trim() ? selectedFolderIcon : meta.icon,
        createdAt: Date.now(),
        prompts: []
      };
      mutateFolders(prev => [...prev, newFolder]);
      setSelectedFolderId(newFolder.id);
      addLog(`Folder '${newFolder.name}' berhasil dibuat.`, 'success');
    }
    
    setNewFolderName('');
    setEditingFolderId(null);
    setSelectedFolderIcon('Folder');
    setIsFolderModalOpen(false);
    setMobileView('prompts');
  };

  const handleOpenEditFolder = (folder, e) => {
    e.stopPropagation();
    setEditingFolderId(folder.id);
    setNewFolderName(folder.name);
    setSelectedFolderIcon(folder.icon || 'Folder');
    setIsFolderModalOpen(true);
  };

  const handleDeleteFolder = (folderId, e) => {
    e.stopPropagation();
    if (folders.length <= 1) {
      alert('Anda harus menyimpan minimal 1 folder.');
      return;
    }
    if (confirm('Hapus folder ini beserta seluruh prompt di dalamnya?')) {
      const remaining = folders.filter(f => f.id !== folderId);
      mutateFolders(() => remaining);
      if (selectedFolderId === folderId) {
        setSelectedFolderId(remaining[0].id);
      }
      addLog('Folder dihapus.', 'info');
    }
  };

  const handleSavePrompt = (e) => {
    e.preventDefault();
    if (!editingPrompt.title.trim() || !editingPrompt.content.trim()) return;

    const targetFolderId = editingPrompt.folderId || selectedFolderId;
    const tagArray = typeof editingPrompt.tags === 'string'
      ? editingPrompt.tags.split(',').map(t => t.trim()).filter(Boolean)
      : editingPrompt.tags;

    if (editingPrompt.id) {
      // Edit: kalau folder diganti, pindahkan prompt ke folder target
      const existing = folders.flatMap(f => f.prompts || []).find(p => p.id === editingPrompt.id);
      const updated = {
        ...(existing || { isFavorite: false }),
        id: editingPrompt.id,
        title: editingPrompt.title,
        content: editingPrompt.content,
        tags: tagArray,
        updatedAt: Date.now()
      };
      mutateFolders(prev => prev.map(folder => {
        const without = (folder.prompts || []).filter(p => p.id !== editingPrompt.id);
        if (folder.id === targetFolderId) return { ...folder, prompts: [updated, ...without] };
        return { ...folder, prompts: without };
      }));
      setSelectedFolderId(targetFolderId);
      setSelectedPromptId(editingPrompt.id);
    } else {
      const newPrompt = {
        id: `p-${Date.now()}`,
        title: editingPrompt.title,
        content: editingPrompt.content,
        tags: tagArray,
        isFavorite: false,
        updatedAt: Date.now()
      };
      mutateFolders(prev => prev.map(folder =>
        folder.id === targetFolderId ? { ...folder, prompts: [newPrompt, ...(folder.prompts || [])] } : folder
      ));
      setSelectedFolderId(targetFolderId);
      setSelectedPromptId(newPrompt.id);
    }

    setIsPromptModalOpen(false);
    setEditingPrompt({ id: null, title: '', content: '', tags: '', folderId: '' });
    setMobileView('detail');
  };

  const handleDeletePrompt = (promptId) => {
    mutateFolders(prev => prev.map(folder => {
      if (folder.id === selectedFolderId) {
        return { ...folder, prompts: folder.prompts.filter(p => p.id !== promptId) };
      }
      return folder;
    }));
    if (selectedPromptId === promptId) {
      setSelectedPromptId(null);
    }
    setMobileView('prompts');
  };

  const copyToClipboard = async (text, id) => {
    let ok = false;
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(text);
        ok = true;
      }
    } catch (err) {}
    if (!ok) {
      try {
        const textarea = document.createElement('textarea');
        textarea.value = text;
        textarea.style.position = 'fixed';
        textarea.style.opacity = '0';
        document.body.appendChild(textarea);
        textarea.focus();
        textarea.select();
        textarea.setSelectionRange(0, text.length);
        ok = document.execCommand('copy');
        document.body.removeChild(textarea);
      } catch (err) {
        console.error('Failed to copy text', err);
      }
    }
    if (ok) {
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
    } else {
      alert('Gagal menyalin. Tekan lama teks prompt lalu pilih Salin.');
    }
  };

  const handleExportBackup = async () => {
    const json = JSON.stringify(folders, null, 2);
    const filename = `PromptVault_Backup_${new Date().toISOString().slice(0, 10)}.json`;
    const file = new File([json], filename, { type: 'application/json' });
    try {
      // iPhone: lewat lembar Bagikan (simpan ke Files / AirDrop / dll)
      if (navigator.canShare?.({ files: [file] })) {
        await navigator.share({ files: [file], title: 'PromptVault Backup' });
        addLog('Backup dibagikan lewat lembar Bagikan.', 'success');
        return;
      }
    } catch (err) {
      if (err?.name === 'AbortError') return;
    }
    const url = URL.createObjectURL(file);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
    addLog('Ekspor data cadangan JSON berhasil.', 'success');
  };

  const handleImportBackup = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const imported = JSON.parse(event.target.result);
        if (Array.isArray(imported) && imported.length > 0 && imported[0].prompts) {
          if (!confirm('Impor akan MENGGANTI semua data vault saat ini. Lanjut?')) return;
          mutateFolders(() => imported);
          setSelectedFolderId(imported[0].id);
          setSelectedPromptId(null);
          addLog('Import data vault JSON berhasil!', 'success');
          alert('Data Prompt Vault berhasil diimpor!');
        } else {
          alert('Format JSON tidak valid.');
        }
      } catch (err) {
        alert('Gagal membaca file JSON cadangan.');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const handleEnhancePromptWithAI = async () => {
    if (!aiPromptInput.trim()) return;
    if (!geminiKey.trim()) {
      alert('Isi dulu Gemini API Key di Pengaturan (ikon gerigi).');
      return;
    }
    setIsAiGenerating(true);

    try {
      const systemPrompt = "Act as an expert prompt engineer. Enhance and refine the user's rough prompt idea into a structured, highly effective, professional system prompt for LLMs. Include guidelines, variables, and ideal tone.";
      const userQuery = `Refine this prompt idea: "${aiPromptInput}"`;
      const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent`;

      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-goog-api-key': geminiKey.trim() },
        body: JSON.stringify({
          contents: [{ parts: [{ text: userQuery }] }],
          systemInstruction: { parts: [{ text: systemPrompt }] }
        })
      });

      const data = await response.json();
      if (!response.ok) throw new Error(data?.error?.message || `HTTP ${response.status}`);
      const generatedText = data?.candidates?.[0]?.content?.parts?.[0]?.text;
      if (!generatedText) throw new Error('Respons AI kosong.');

      setEditingPrompt(prev => ({
        ...prev,
        title: prev.title || aiPromptInput.slice(0, 30) + " (AI)",
        content: generatedText
      }));

      setShowAiModal(false);
      setAiPromptInput('');
    } catch (err) {
      console.error("AI Generation error:", err);
      addLog(`AI error: ${err.message}`, 'error');
      alert(`Gagal menghubungi AI: ${err.message}`);
    } finally {
      setIsAiGenerating(false);
    }
  };

  const isDark = isDarkMode;
  const glassStyle = isDark ? UI_STYLES.glassPanelDark : UI_STYLES.glassPanelLight;
  const inputStyle = isDark ? UI_STYLES.glassInputDark : UI_STYLES.glassInputLight;

  return (
    <div className={`pv-root h-[100dvh] flex flex-col font-sans transition-colors duration-300 overflow-hidden selection:bg-indigo-500 selection:text-white ${isDark ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-800'}`}>
      
      <div className="pv-statusbar" />
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        <div className={`absolute -top-40 -left-40 w-80 h-80 rounded-full blur-3xl opacity-30 ${isDark ? 'bg-indigo-600/40' : 'bg-indigo-300/60'}`} />
        <div className={`absolute top-1/2 -right-40 w-80 h-80 rounded-full blur-3xl opacity-20 ${isDark ? 'bg-purple-600/40' : 'bg-purple-300/60'}`} />
      </div>

      {/* macOS Style Glass Header */}
      <header className={`sticky top-0 z-30 h-14 md:h-16 border-b backdrop-blur-md flex items-center justify-between px-3 md:px-6 shrink-0 ${isDark ? 'border-slate-800/80 bg-slate-950/70' : 'border-slate-200/80 bg-white/70'}`}>
        <div className="flex items-center space-x-2 md:space-x-3 truncate">
          {mobileView !== 'folders' && (
            <button 
              onClick={() => setMobileView(mobileView === 'detail' ? 'prompts' : 'folders')}
              className="md:hidden p-1.5 rounded-lg bg-indigo-500/10 text-indigo-400 hover:bg-indigo-500/20 mr-1 shrink-0 flex items-center text-xs font-semibold"
            >
              <ChevronLeft className="w-4 h-4 mr-0.5" />
              <span>{mobileView === 'detail' ? 'Prompts' : 'Folder'}</span>
            </button>
          )}

          <div className="hidden sm:flex items-center space-x-1.5 mr-1 shrink-0">
            <div className="w-3 h-3 rounded-full bg-rose-500/80 border border-rose-600/50" />
            <div className="w-3 h-3 rounded-full bg-amber-500/80 border border-amber-600/50" />
            <div className="w-3 h-3 rounded-full bg-emerald-500/80 border border-emerald-600/50" />
          </div>

          <div className="flex items-center space-x-1.5 truncate">
            <Logo size={28} className="shrink-0 drop-shadow-md" />
            <span className="font-semibold text-sm md:text-base tracking-tight bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 bg-clip-text text-transparent truncate">
              PromptVault <span className="text-[10px] px-1.5 py-0.5 rounded-full border border-indigo-500/30 text-indigo-400 font-mono">PRO</span>
            </span>
          </div>
        </div>

        <div className="flex items-center space-x-2 shrink-0">
          {/* Cloud Sync Status Indicator */}
          <button 
            onClick={() => setIsSettingsOpen(true)}
            className="flex items-center space-x-1 px-2 py-1 rounded-xl text-[10px] font-mono border border-slate-800/40 bg-slate-900/50 text-slate-400 hover:border-indigo-500/50 transition-all" 
            title="Status penyimpanan & pengaturan"
          >
            {saveStatus === 'saved' && <HardDrive className="w-3.5 h-3.5 text-emerald-400" />}
            {saveStatus === 'error' && <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />}
            <span className="hidden lg:inline">{saveStatus === 'saved' ? 'Tersimpan' : 'Gagal simpan'}</span>
          </button>

          <button 
            onClick={() => setIsSettingsOpen(true)}
            className={`p-2 rounded-xl border transition-all shrink-0 ${isDark ? 'border-slate-800 bg-slate-900 text-slate-300' : 'border-slate-200 bg-slate-100 text-slate-700'}`}
            title="Pengaturan & Log Diagnostik"
          >
            <Settings className="w-4 h-4" />
          </button>

          <button 
            onClick={() => setIsDarkMode(!isDarkMode)}
            className={`p-2 rounded-xl border transition-all shrink-0 ${isDark ? 'border-slate-800 bg-slate-900 text-amber-400' : 'border-slate-200 bg-slate-100 text-slate-700'}`}
            title="Switch Theme"
          >
            {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>
        </div>
      </header>

      <div className="flex-1 flex overflow-hidden z-10 relative">
        {/* PANEL 1: Folders List */}
        <aside className={`${mobileView === 'folders' ? 'flex' : 'hidden'} md:flex w-full md:w-60 border-r flex-col p-3 space-y-3 shrink-0 ${isDark ? 'border-slate-800/80 bg-slate-950/50' : 'border-slate-200/80 bg-slate-50/50'}`}>
          <div className="flex items-center justify-between px-2 pt-1">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">Brankas Folder</span>
            <button 
              onClick={() => {
                setEditingFolderId(null);
                setNewFolderName('');
                setSelectedFolderIcon('Folder');
                setIsFolderModalOpen(true);
              }}
              className="p-1 rounded-lg hover:bg-indigo-500/20 text-indigo-400 transition-colors"
              title="Tambah Folder Baru"
            >
              <FolderPlus className="w-4 h-4" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto space-y-1.5 pr-1 custom-scrollbar">
            {folders.map((folder) => {
              const isActive = folder.id === selectedFolderId;
              const FolderIconComponent = ICON_MAP[folder.icon] || Folder;

              return (
                <div 
                  key={folder.id}
                  onClick={() => handleSelectFolder(folder.id)}
                  className={`group flex items-center justify-between px-3 py-3 md:py-2.5 rounded-2xl text-xs font-medium cursor-pointer transition-all ${
                    isActive 
                      ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30' 
                      : isDark ? 'text-slate-300 hover:bg-slate-800/60' : 'text-slate-700 hover:bg-slate-200/70'
                  }`}
                >
                  <div className="flex items-center space-x-2.5 truncate">
                    <FolderIconComponent className={`w-4 h-4 shrink-0 ${isActive ? 'text-white' : 'text-indigo-400'}`} />
                    <span className="truncate">{folder.name}</span>
                  </div>
                  <div className="flex items-center space-x-1 shrink-0">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] ${isActive ? 'bg-indigo-700 text-indigo-100' : isDark ? 'bg-slate-800 text-slate-400' : 'bg-slate-200 text-slate-600'}`}>
                      {folder.prompts?.length || 0}
                    </span>

                    <button 
                      onClick={(e) => handleOpenEditFolder(folder, e)}
                      className="opacity-100 md:opacity-0 md:group-hover:opacity-100 p-1 rounded hover:bg-indigo-500/20 text-slate-400 hover:text-white"
                      title="Edit Nama/Ikon Folder"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>

                    {folders.length > 1 && (
                      <button 
                        onClick={(e) => handleDeleteFolder(folder.id, e)}
                        className="opacity-100 md:opacity-0 md:group-hover:opacity-100 p-1 rounded hover:bg-rose-500/20 text-rose-400"
                        title="Hapus Folder"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {allTags.length > 0 && (
            <div className="pt-2 border-t border-slate-800/50">
              <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-400 px-2 block mb-2">Filter Tag</span>
              <div className="flex flex-wrap gap-1 max-h-24 overflow-y-auto">
                <button
                  onClick={() => setSelectedTag(null)}
                  className={`px-2 py-1 text-[10px] rounded-lg transition-all ${!selectedTag ? 'bg-indigo-500 text-white' : isDark ? 'bg-slate-800 text-slate-400' : 'bg-slate-200 text-slate-600'}`}
                >
                  Semua
                </button>
                {allTags.map(tag => (
                  <button
                    key={tag}
                    onClick={() => setSelectedTag(tag === selectedTag ? null : tag)}
                    className={`px-2 py-1 text-[10px] rounded-lg transition-all ${selectedTag === tag ? 'bg-indigo-500 text-white' : isDark ? 'bg-slate-800 text-slate-400' : 'bg-slate-200 text-slate-600'}`}
                  >
                    #{tag}
                  </button>
                ))}
              </div>
            </div>
          )}
        </aside>

        {/* PANEL 2: Prompts Item List */}
        <section className={`${mobileView === 'prompts' ? 'flex' : 'hidden'} md:flex w-full md:w-72 border-r flex-col p-3 space-y-3 shrink-0 ${isDark ? 'border-slate-800/80 bg-slate-900/40' : 'border-slate-200/80 bg-white/50'}`}>
          <div className="flex items-center justify-between px-1">
            <h2 className="text-xs font-bold truncate pr-2">{activeFolder?.name || 'Folder Prompts'}</h2>
            <button 
              onClick={() => {
                setEditingPrompt({ id: null, title: '', content: '', tags: '', folderId: selectedFolderId });
                setIsPromptModalOpen(true);
              }}
              className={`px-2.5 py-1.5 rounded-xl text-xs flex items-center space-x-1 shrink-0 ${UI_STYLES.btnPrimary}`}
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Prompt Baru</span>
            </button>
          </div>

          <div className="relative w-full">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input 
              type="text" 
              placeholder="Cari kata kunci prompt..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className={`w-full text-xs pl-8 pr-3 py-1.5 rounded-xl outline-none ${inputStyle}`}
            />
          </div>

          <div className="flex-1 overflow-y-auto space-y-2 pr-1 custom-scrollbar">
            {filteredPrompts.length === 0 ? (
              <div className="text-center py-10 px-3">
                <FileText className="w-8 h-8 mx-auto text-slate-500 mb-2 opacity-40" />
                <p className="text-xs text-slate-400">Belum ada prompt.</p>
              </div>
            ) : (
              filteredPrompts.map((p) => {
                const isSelected = activePrompt?.id === p.id;
                return (
                  <div 
                    key={p.id}
                    onClick={() => handleSelectPrompt(p.id)}
                    className={`p-3 rounded-2xl cursor-pointer border transition-all relative ${
                      isSelected 
                        ? isDark ? 'bg-indigo-950/60 border-indigo-500/80' : 'bg-indigo-50 border-indigo-400'
                        : isDark ? 'bg-slate-900/80 border-slate-800' : 'bg-white border-slate-200'
                    }`}
                  >
                    <h3 className={`text-xs font-semibold line-clamp-1 ${isSelected ? 'text-indigo-400' : ''}`}>
                      {p.title}
                    </h3>
                    <p className="text-[11px] text-slate-400 line-clamp-2 mt-1 leading-relaxed">
                      {p.content}
                    </p>
                    <div className="flex items-center justify-between mt-2 pt-2 border-t border-slate-800/20">
                      <div className="flex items-center space-x-1 overflow-hidden">
                        {(p.tags || []).slice(0, 2).map(tag => (
                          <span key={tag} className="text-[9px] px-1.5 py-0.5 rounded bg-indigo-500/10 text-indigo-400 font-mono">
                            #{tag}
                          </span>
                        ))}
                      </div>
                      <span className="text-[9px] text-slate-500 shrink-0">
                        {new Date(p.updatedAt).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
                      </span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </section>

        {/* PANEL 3: Detail Workspace */}
        <main className={`${mobileView === 'detail' ? 'flex' : 'hidden'} md:flex flex-1 flex-col p-4 md:p-6 overflow-y-auto relative w-full`}>
          {activePrompt ? (
            <div className={`w-full max-w-4xl mx-auto p-5 md:p-8 rounded-3xl space-y-5 ${glassStyle}`}>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b pb-4 border-slate-800/40">
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-400 font-mono">
                      {activeFolder?.name}
                    </span>
                  </div>
                  <h1 className="text-lg md:text-2xl font-bold tracking-tight">{activePrompt.title}</h1>
                </div>

                <div className="flex items-center space-x-2 shrink-0 self-start sm:self-auto">
                  <button 
                    onClick={() => copyToClipboard(activePrompt.content, activePrompt.id)}
                    className={`px-3 py-2 rounded-xl text-xs flex items-center space-x-1.5 ${UI_STYLES.btnPrimary}`}
                  >
                    {copiedId === activePrompt.id ? <Check className="w-3.5 h-3.5 text-emerald-300" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedId === activePrompt.id ? 'Tersalin!' : 'Salin'}</span>
                  </button>

                  <button 
                    onClick={() => {
                      setEditingPrompt({
                        id: activePrompt.id,
                        title: activePrompt.title,
                        content: activePrompt.content,
                        tags: (activePrompt.tags || []).join(', '),
                        folderId: selectedFolderId
                      });
                      setIsPromptModalOpen(true);
                    }}
                    className={`p-2 rounded-xl text-xs border ${isDark ? UI_STYLES.btnSecondaryDark : UI_STYLES.btnSecondaryLight}`}
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>

                  <button 
                    onClick={() => handleDeletePrompt(activePrompt.id)}
                    className="p-2 rounded-xl text-xs border border-rose-500/30 bg-rose-500/10 text-rose-400 hover:bg-rose-500/20"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {activePrompt.tags && activePrompt.tags.length > 0 && (
                <div className="flex items-center space-x-2">
                  <Tag className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <div className="flex flex-wrap gap-1">
                    {activePrompt.tags.map(t => (
                      <span key={t} className="text-[10px] px-2 py-0.5 rounded bg-indigo-500/15 text-indigo-400 font-mono">
                        #{t}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              <div className="space-y-1.5">
                <label className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">Isi Prompt Vault</label>
                <div className={`p-4 md:p-5 rounded-2xl border font-mono text-xs md:text-sm leading-relaxed whitespace-pre-wrap select-all ${
                  isDark ? 'bg-slate-950/80 border-slate-800/80 text-slate-200' : 'bg-slate-50 border-slate-200 text-slate-800'
                }`}>
                  {activePrompt.content}
                </div>
              </div>
            </div>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-center p-6">
              <Logo size={64} className="mb-3 opacity-80" />
              <h3 className="text-base font-bold">Pilih Prompt</h3>
              <p className="text-xs text-slate-400 max-w-xs mt-1">
                Pilih prompt dari folder Anda atau buat prompt baru.
              </p>
            </div>
          )}
        </main>
      </div>

      {/* MODAL 1: Smart Folder Modal (Create & Edit) */}
      {isFolderModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className={`w-full max-w-sm p-5 rounded-3xl space-y-4 shadow-2xl ${glassStyle}`}>
            <h3 className="text-sm font-bold">
              {editingFolderId ? 'Edit Folder Vault' : 'Tambah Folder Vault Baru'}
            </h3>
            <form onSubmit={handleSaveFolder} className="space-y-3">
              <div>
                <label className="text-[11px] text-slate-400 block mb-1">
                  {editingFolderId ? 'Nama Folder' : 'Nama Folder (Opsional - Auto Detect)'}
                </label>
                <input 
                  type="text" 
                  placeholder={editingFolderId ? "Nama folder..." : "Misal: Python Automation / Kosongkan"} 
                  value={newFolderName}
                  onChange={(e) => {
                    setNewFolderName(e.target.value);
                    if (!editingFolderId) {
                      const detected = autoDetectFolderMeta(e.target.value, folders.length);
                      setSelectedFolderIcon(detected.icon);
                    }
                  }}
                  className={`w-full text-xs p-3 rounded-xl outline-none ${inputStyle}`}
                  autoFocus
                />
              </div>

              <div>
                <label className="text-[11px] text-slate-400 block mb-1.5">Pilih Ikon Monoline</label>
                <div className="grid grid-cols-6 gap-1.5">
                  {AVAILABLE_ICONS.map(iconName => {
                    const IconComp = ICON_MAP[iconName] || Folder;
                    const isSelected = selectedFolderIcon === iconName;
                    return (
                      <button
                        type="button"
                        key={iconName}
                        onClick={() => setSelectedFolderIcon(iconName)}
                        className={`p-2 rounded-xl flex items-center justify-center border transition-all ${
                          isSelected 
                            ? 'bg-indigo-600 text-white border-indigo-400' 
                            : isDark ? 'bg-slate-800/80 border-slate-700 text-slate-300' : 'bg-slate-100 border-slate-300 text-slate-700'
                        }`}
                      >
                        <IconComp className="w-4 h-4" />
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="flex justify-end space-x-2 pt-2">
                <button 
                  type="button" 
                  onClick={() => setIsFolderModalOpen(false)}
                  className={`px-3 py-2 rounded-xl text-xs border ${isDark ? UI_STYLES.btnSecondaryDark : UI_STYLES.btnSecondaryLight}`}
                >
                  Batal
                </button>
                <button type="submit" className={`px-4 py-2 rounded-xl text-xs ${UI_STYLES.btnPrimary}`}>
                  Simpan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: Add / Edit Prompt */}
      {isPromptModalOpen && (
        <div className="fixed inset-0 z-50 flex items-start md:items-center justify-center p-4 pt-[calc(env(safe-area-inset-top)+1rem)] bg-black/60 backdrop-blur-sm overflow-y-auto">
          <div className={`w-full max-w-xl p-5 my-4 rounded-3xl space-y-4 shadow-2xl ${glassStyle}`}>
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold">
                {editingPrompt.id ? 'Edit Prompt Vault' : 'Buat Prompt Baru'}
              </h3>
              <button 
                type="button"
                onClick={() => setShowAiModal(true)}
                className="px-2.5 py-1.5 rounded-xl text-[11px] bg-gradient-to-r from-purple-500 to-pink-500 text-white flex items-center space-x-1"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>AI Enhancer</span>
              </button>
            </div>

            <form onSubmit={handleSavePrompt} className="space-y-3">
              <div>
                <label className="text-[11px] text-slate-400 block mb-1">Judul Prompt</label>
                <input 
                  type="text" 
                  placeholder="Judul Prompt..." 
                  value={editingPrompt.title}
                  onChange={(e) => setEditingPrompt({...editingPrompt, title: e.target.value})}
                  className={`w-full text-xs p-2.5 rounded-xl outline-none ${inputStyle}`}
                  required
                />
              </div>

              <div>
                <label className="text-[11px] text-slate-400 block mb-1">Folder Target</label>
                <select 
                  value={editingPrompt.folderId || selectedFolderId}
                  onChange={(e) => setEditingPrompt({...editingPrompt, folderId: e.target.value})}
                  className={`w-full text-xs p-2.5 rounded-xl outline-none ${inputStyle}`}
                >
                  {folders.map(f => (
                    <option key={f.id} value={f.id} className={isDark ? 'bg-slate-900' : 'bg-white'}>
                      {f.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-[11px] text-slate-400 block mb-1">Tag (Pisahkan dengan koma)</label>
                <input 
                  type="text" 
                  placeholder="Coding, React" 
                  value={editingPrompt.tags}
                  onChange={(e) => setEditingPrompt({...editingPrompt, tags: e.target.value})}
                  className={`w-full text-xs p-2.5 rounded-xl outline-none ${inputStyle}`}
                />
              </div>

              <div>
                <label className="text-[11px] text-slate-400 block mb-1">Isi Prompt</label>
                <textarea 
                  rows={6}
                  placeholder="Tulis instruksi prompt di sini..." 
                  value={editingPrompt.content}
                  onChange={(e) => setEditingPrompt({...editingPrompt, content: e.target.value})}
                  className={`w-full text-xs p-2.5 rounded-xl outline-none font-mono ${inputStyle}`}
                  required
                />
              </div>

              <div className="flex justify-end space-x-2 pt-2">
                <button 
                  type="button" 
                  onClick={() => setIsPromptModalOpen(false)}
                  className={`px-3 py-2 rounded-xl text-xs border ${isDark ? UI_STYLES.btnSecondaryDark : UI_STYLES.btnSecondaryLight}`}
                >
                  Batal
                </button>
                <button type="submit" className={`px-4 py-2 rounded-xl text-xs ${UI_STYLES.btnPrimary}`}>
                  Simpan Prompt
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 3: Gemini AI Prompt Enhancer Assistant */}
      {showAiModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md">
          <div className={`w-full max-w-md p-5 rounded-3xl space-y-3 shadow-2xl border border-purple-500/40 ${glassStyle}`}>
            <div className="flex items-center space-x-2">
              <Sparkles className="w-4 h-4 text-purple-400" />
              <h3 className="text-sm font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                Gemini AI Prompt Generator
              </h3>
            </div>
            
            <p className="text-xs text-slate-300">
              Tulis ide kasar prompt Anda, AI akan memperbaikinya menjadi prompt profesional.
            </p>

            <textarea 
              rows={4}
              placeholder="Contoh: Buatkan prompt untuk merangkum email bisnis secara profesional..." 
              value={aiPromptInput}
              onChange={(e) => setAiPromptInput(e.target.value)}
              className={`w-full text-xs p-2.5 rounded-xl outline-none ${inputStyle}`}
            />

            <div className="flex justify-end space-x-2 pt-2">
              <button 
                type="button" 
                onClick={() => setShowAiModal(false)}
                className={`px-3 py-1.5 rounded-xl text-xs border ${isDark ? UI_STYLES.btnSecondaryDark : UI_STYLES.btnSecondaryLight}`}
              >
                Batal
              </button>
              <button 
                type="button"
                onClick={handleEnhancePromptWithAI}
                disabled={isAiGenerating}
                className={`px-3 py-1.5 rounded-xl text-xs flex items-center space-x-1.5 ${UI_STYLES.btnPrimary}`}
              >
                {isAiGenerating ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Merancang...</span>
                  </>
                ) : (
                  <>
                    <Zap className="w-3.5 h-3.5" />
                    <span>Generate</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 4: Settings & Diagnostics Panel */}
      {isSettingsOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md">
          <div className={`w-full max-w-lg max-h-[85dvh] overflow-y-auto p-5 rounded-3xl space-y-4 shadow-2xl ${glassStyle}`}>
            <div className="flex items-center justify-between border-b pb-3 border-slate-800/40">
              <div className="flex items-center space-x-2">
                <Activity className="w-4 h-4 text-indigo-400" />
                <h3 className="text-sm font-bold">Diagnostik Vault & Pengaturan</h3>
              </div>
              <button 
                onClick={() => setIsSettingsOpen(false)}
                className="text-xs text-slate-400 hover:text-white"
              >
                Tutup
              </button>
            </div>

            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className={`p-3 rounded-2xl border ${isDark ? 'bg-slate-950/60 border-slate-800' : 'bg-slate-100 border-slate-200'}`}>
                  <span className="text-[10px] text-slate-400 block mb-1">Status Storage</span>
                  <span className="font-semibold capitalize flex items-center space-x-1">
                    {saveStatus === 'saved' && <CheckCircle className="w-3.5 h-3.5 text-emerald-400 mr-1" />}
                    {saveStatus === 'saved' ? 'Tersimpan di perangkat' : 'Gagal simpan'}
                  </span>
                </div>
                <div className={`p-3 rounded-2xl border ${isDark ? 'bg-slate-950/60 border-slate-800' : 'bg-slate-100 border-slate-200'}`}>
                  <span className="text-[10px] text-slate-400 block mb-1">Total Vault Data</span>
                  <span className="font-semibold">{folders.length} Folder, {folders.reduce((acc, f) => acc + (f.prompts?.length || 0), 0)} Prompts</span>
                </div>
              </div>

              <div>
                <label className="text-[10px] font-semibold uppercase tracking-wider text-slate-400 block mb-1.5">Gemini API Key (untuk AI Enhancer)</label>
                <input
                  type="password"
                  autoComplete="off"
                  placeholder="Tempel API key di sini..."
                  value={geminiKey}
                  onChange={(e) => setGeminiKey(e.target.value)}
                  className={`w-full text-xs p-2.5 rounded-xl outline-none font-mono ${inputStyle}`}
                />
                <p className="text-[10px] text-slate-500 mt-1">Disimpan hanya di perangkat ini, tidak dikirim ke mana pun selain ke Google saat Generate.</p>
              </div>

              <div>
                <label className="text-[10px] font-semibold uppercase tracking-wider text-slate-400 block mb-1.5">Backup & Pemulihan Data</label>
                <div className="flex space-x-2">
                  <button 
                    onClick={handleExportBackup}
                    className={`flex-1 py-2 rounded-xl text-xs flex items-center justify-center space-x-1 border ${isDark ? UI_STYLES.btnSecondaryDark : UI_STYLES.btnSecondaryLight}`}
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Ekspor / Bagikan Backup</span>
                  </button>
                  
                  <button 
                    onClick={() => fileInputRef.current?.click()}
                    className={`flex-1 py-2 rounded-xl text-xs flex items-center justify-center space-x-1 border ${isDark ? UI_STYLES.btnSecondaryDark : UI_STYLES.btnSecondaryLight}`}
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>Impor JSON</span>
                  </button>
                  <input type="file" ref={fileInputRef} onChange={handleImportBackup} accept=".json" className="hidden" />
                </div>
              </div>

              <div>
                <label className="text-[10px] font-semibold uppercase tracking-wider text-slate-400 block mb-1">Log Diagnostik System (Realtime)</label>
                <div className={`p-3 rounded-2xl border h-36 overflow-y-auto font-mono text-[10px] space-y-1.5 ${isDark ? 'bg-slate-950 border-slate-800 text-slate-300' : 'bg-slate-900 text-slate-200'}`}>
                  {storageLogs.length === 0 ? (
                    <span className="text-slate-500">Belum ada aktivitas tercatat.</span>
                  ) : (
                    storageLogs.map((log, i) => (
                      <div key={i} className="flex space-x-2">
                        <span className="text-slate-500 shrink-0">[{log.time}]</span>
                        <span className={log.type === 'error' ? 'text-rose-400' : log.type === 'success' ? 'text-emerald-400' : log.type === 'warn' ? 'text-amber-400' : 'text-slate-300'}>
                          {log.msg}
                        </span>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}

class ErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error("Critical Runtime Error caught by boundary:", error, errorInfo);
  }

  handleExportEmergencyData = () => {
    try {
      const data = localStorage.getItem('pv_folders') || '[]';
      const blob = new Blob([data], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `PromptVault_Emergency_Backup_${Date.now()}.json`;
      a.click();
    } catch (e) {
      alert('Gagal mengeksport data darurat.');
    }
  };

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-slate-950 text-slate-100 flex items-center justify-center p-6">
          <div className="max-w-md w-full bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4 shadow-2xl text-center">
            <AlertTriangle className="w-12 h-12 text-rose-500 mx-auto" />
            <h2 className="text-lg font-bold">Terjadi Kesalahan Aplikasi</h2>
            <p className="text-xs text-slate-400 font-mono bg-slate-950 p-3 rounded-xl text-left overflow-x-auto">
              {this.state.error?.toString() || 'Unknown Runtime Exception'}
            </p>
            <div className="flex flex-col space-y-2 pt-2">
              <button 
                onClick={() => this.setState({ hasError: false, error: null })}
                className="w-full py-2.5 rounded-xl text-xs font-semibold bg-indigo-600 text-white"
              >
                Coba Render Ulang (Reset UI State)
              </button>
              <button 
                onClick={this.handleExportEmergencyData}
                className="w-full py-2.5 rounded-xl text-xs font-semibold bg-slate-800 text-slate-300 flex items-center justify-center space-x-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export Data Darurat (JSON)</span>
              </button>
            </div>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

export default function App() {
  return (
    <ErrorBoundary>
      <PromptVaultApp />
    </ErrorBoundary>
  );
}